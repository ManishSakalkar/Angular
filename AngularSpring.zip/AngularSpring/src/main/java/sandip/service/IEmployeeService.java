package sandip.service;

import java.util.List;
import java.util.Optional;

import sandip.model.Employee;

public interface IEmployeeService {

	Integer saveEmployee(Employee s);
	void updateEmployee(Employee s);
	
	void deleteEmployee(Integer id);

	Optional<Employee> getOneEmployee(Integer id);
	List<Employee> getAllEmployees();

	boolean isEmployeeExist(Integer id);
}

package sandip.util;

import org.springframework.stereotype.Component;


import sandip.model.Employee;

@Component
public class EmployeeUtil {

	public void mapToActualObject(Employee actual, Employee employee) {
		if(employee.getName()!=null)
			actual.setName(employee.getName());
		actual.setFee(employee.getFee());
		actual.setCourse(employee.getCourse());
		if(employee.getEmail()!=null)
			actual.setEmail(employee.getEmail());
		actual.setAddr(employee.getAddr());
	}

}

export class Employee {
    constructor(
    public id: number,
    public name: string,
    public fee: number,
    public course: string,
    public email: string,
    public phoneno: number,
    public gender: string,
    public addr: string
    ){}
}

import { EmployeeService } from '../employee.service';
import { Employee } from '../employee';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-employee-all',
  templateUrl: './employee-all.component.html',
  styleUrls: ['./employee-all.component.css']
})
export class EmployeeAllComponent implements OnInit {
  // send this data to UI
  employees: Employee[] = [];
  message: string ='';
  // inject service layer
  constructor(private service: EmployeeService, private router: Router) { }

  // on page load call this method
  ngOnInit(): void {
    this.getAllEmployees();
  }
  // fetch data from backend application using service
  // tslint:disable-next-line: typedef
  getAllEmployees() {
    return this.service.getAllEmployees()
    .subscribe(
      data => {
        this.employees = data;
      }, error => {
        console.log(error);
      }
    );
  }

  // tslint:disable-next-line: typedef
  deleteEmployee(id: number) {
    if (confirm('Do you want to delete?')) {
      this.service.deleteOneEmployee(id)
      .subscribe(data => {
        this.message = data;
        this.getAllEmployees();
      }, error => {
        console.log(error);
      });
    } else {
      this.message = '';
    }
  }

  // tslint:disable-next-line: typedef
  editEmployee(id: number) {
    this.router.navigate(['edit', id]);
  }

}

import { Injectable } from "@angular/core";
import{ HttpClient } from '@angular/common/http';
import { Observable } from "rxjs";
import { Employee } from './employee';

@Injectable({
    providedIn: 'root'
})
export class EmployeeService{
    private basePath = 'http://localhost:8090/rest/employee';

    constructor(private http: HttpClient){
    }
    getAllEmployees(): Observable<Employee[]> {
        return this.http.get<Employee[]>(`${this.basePath}/all`);
      }
    
      deleteOneEmployee(id: number): Observable<any> {
        return this.http.delete(`${this.basePath}/remove/${id}`, {responseType: 'text'});
      }
    
      createEmployee(employee: Employee): Observable<any> {
        return this.http.post(`${this.basePath}/save`, employee, {responseType: 'text'});
      }
    
      
      getOneEmployee(id: number): Observable<Employee> {
        return this.http.get<Employee>(`${this.basePath}/one/${id}`);
      }
    
      updateEmployee(id: number, employee: Employee): Observable<any> {
        return this.http.put(`${this.basePath}/modify/${id}`, employee, {responseType : 'text'});
      }
}
import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Employee } from '../employee';

@Component({
  selector: 'app-employee-create',
  templateUrl: './employee-create.component.html',
  styleUrls: ['./employee-create.component.css']
})
export class EmployeeCreateComponent implements OnInit {
  // form backing object
  // form backing object
  employee: Employee = new Employee(0,'',0,'','',0,'','');
  // message to ui
  // message to ui
  message: string = '';

  // inject service class
  constructor(private service: EmployeeService) { }

  ngOnInit(): void {
    // when page is loaded clear form data
    this.employee = new Employee(0,'',0,'','',0,'','');
  }

  // tslint:disable-next-line: typedef
  createEmployee() {
    this.service.createEmployee(this.employee)
    .subscribe(data => {
      this.message = data; // read message
      this.employee = new Employee(0,'',0,'','',0,'',''); // clear form
    }, error => {
      console.log(error);
    });
  }

}

import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Employee } from '../employee';

@Component({
  selector: 'app-employee-edit',
  templateUrl: './employee-edit.component.html',
  styleUrls: ['./employee-edit.component.css']
})
export class EmployeeEditComponent implements OnInit {
  // declare variables
  // declare variables
  id!: number;
  employee!: Employee;

  // inject service and acivated Route param
  constructor(private service: EmployeeService, private router: Router, private activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {
    // read id sent by all component as /edit/id
    // tslint:disable-next-line: no-string-literal
    this.id = this.activatedRoute.snapshot.params['id'];
    // make service call to get employee object
    this.service.getOneEmployee(this.id).subscribe(
      data => {
      this.employee = data;
      console.log(this.employee);
    }, error => {
      console.log(error);
    });
  }

  // tslint:disable-next-line: typedef
  updateEmployee() {
    this.service.updateEmployee(this.id, this.employee)
    .subscribe( data => {
      console.log(data);
      this.router.navigate(['all']);
    });
  }

}
